## Hadith of the day

Firefox WebExtension that displays a hadith from a collection of ahadith.

The selected hadith were scraped from [ashrafuzzaman's repository](https://github.com/ashrafuzzaman/hadith/) and parsed into a json file with a python script.
:tulip:
